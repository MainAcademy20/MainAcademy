import telebot

bot = telebot.TeleBot('1100313428:AAEcstTf47PrdHKR_ug2W-2cuKnkXg9h6JE')
keyboard1 = telebot.types.ReplyKeyboardMarkup()
keyboard1.row('total flow', 'rbs flow', 'ptks flow')


@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, 'Welcome to the analytic bot!', reply_markup=keyboard1)


@bot.message_handler(content_types=['text'])
def send_text(message):
    if message.text.lower() == 'total flow':
        bot.send_message(message.chat.id, 'TOTAL FLOW: <a href="https://app.powerbi.com/reportEmbed?reportId=7e1fa8cf-9335-401c-9b99-59e9a02a2c51&autoAuth=true&ctid=4b821475-d00a-4f81-92dc-c9e5235ddd82&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLXdlc3QtZXVyb3BlLWQtcHJpbWFyeS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldC8ifQ%3D%3D">Лінк</a>')
    elif message.text.lower() == 'rbs flow':
        bot.send_message(message.chat.id, 'RBS FLOW: <a href="https://app.powerbi.com/reportEmbed?reportId=83bdd4ef-798d-4272-a3a1-52ae03ca5cff&autoAuth=true&ctid=4b821475-d00a-4f81-92dc-c9e5235ddd82&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLXdlc3QtZXVyb3BlLWQtcHJpbWFyeS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldC8ifQ%3D%3D">Лінк</a>')
    elif message.text.lower() == 'ptks flow':
        bot.send_message(message.chat.id, 'RTKS FLOW: <a href="https://app.powerbi.com/reportEmbed?reportId=7e1fa8cf-9335-401c-9b99-59e9a02a2c51&autoAuth=true&ctid=4b821475-d00a-4f81-92dc-c9e5235ddd82&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLXdlc3QtZXVyb3BlLWQtcHJpbWFyeS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldC8ifQ%3D%3D">Лінк</a>')
    elif message.text.lower() == 'exit':
        bot.send_message(message.chat.id,'RTKS FLOW: <a href="https://app.powerbi.com/reportEmbed?reportId=7e1fa8cf-9335-401c-9b99-59e9a02a2c51&autoAuth=true&ctid=4b821475-d00a-4f81-92dc-c9e5235ddd82&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly93YWJpLXdlc3QtZXVyb3BlLWQtcHJpbWFyeS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldC8ifQ%3D%3D">Лінк</a>')
    elif message.text.lower() == 'Have a nice day':
        bot.send_sticker(message.chat.id, 'CAADAgADZgkAAnlc4gmfCor5YbYYRAI')


@bot.message_handler(content_types=['sticker'])
def sticker_id(message):
    print(message)


bot.polling()
